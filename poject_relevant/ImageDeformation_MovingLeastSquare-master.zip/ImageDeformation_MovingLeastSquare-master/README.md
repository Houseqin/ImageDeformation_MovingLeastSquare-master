# Image Deformation using MovingLeastSquare


Implementation of "Image Deformation Using Moving Least Squares" in C++ (OpenGL / OpenCV)



This application is an implementation of  "Image Deformation Using Moving Least Squares" by Scott Schaefer.


The code is based on the MATLAB code written by Gabriele Lombardi. 



(OpenGL and OpenCV are required)


Watch Video.
https://www.youtube.com/watch?v=a8PZXYjVwGA

